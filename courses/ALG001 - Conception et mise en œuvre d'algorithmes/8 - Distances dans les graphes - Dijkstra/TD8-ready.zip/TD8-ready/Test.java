import java.util.LinkedList;
import java.util.Collection;
import java.util.PriorityQueue;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Arrays;
import java.text.DecimalFormat;




public class Test {

    // pour charger les cartes
    static Carte carte;
    static final String chemin ="./"; // data file location
    Carte ens = new Carte(chemin+"mf.txt");
    


    static HashMap<Ville, HashSet<Ville>> voisins;
    static HashMap<String, HashSet<Ville>> nom;


    static void construitGraphe(Collection<Ville> cv, double minDist) {

	double R = 6371000;
	double latDist = minDist * 180.0 / Math.PI / R;
	// des villes à moins de minDist l'une de l'autre auront au plus une différence de
	// latitude (ou de longitude)  de latDist 
	

	// indication : on peut trier un tableau de villes par Array.sort

	// ici construire le graphe des villes en mettant les bonnes valeurs 
	// dans les tables voisins et nom


    }






    static Ville premiereVille(String s) {
	return(nom.get(s).iterator().next());
    }

    static double Dijkstra(Ville orig, Ville dest) {
	// utiliser Dijkstra pour calculer la longueur du plus court chemin
	// entre v1 et v2
	// rendre -1 s'il n'y a pas de chemin

      return 0;
    }




  public static void initMayotte(double minDist){
	Carte ens = new Carte(chemin+"mf.txt");
	construitGraphe(ens.villes(), minDist);
  }

  public static void initFrance(double minDist){
	Carte ens = new Carte(chemin+"fr.txt");
	construitGraphe(ens.villes(), minDist);

  }


    public static void test1(double minDist) {
	System.out.println();
    	System.out.println("Mayotte, pas de "+minDist);
    	initMayotte(minDist);

    	 Ville v1 = premiereVille("Accua") ;
    	 Ville v2 = premiereVille("Moutsamoudou");
    	 Ville v3 = premiereVille("Bandraboua");
    	 Ville v4 = premiereVille("Mambutzou");
	afficheDijkstra(v1, v2);
	afficheDijkstra(v2, v1);
	afficheDijkstra(v1, v3);
	afficheDijkstra(v3, v1);
	afficheDijkstra(v1, v4);
	afficheDijkstra(v4, v1);
	afficheDijkstra(v2, v3);
    }


    public static void afficheDijkstra(Ville v1, Ville v2) {
	DecimalFormat df = new DecimalFormat("#.000");
	double d = Dijkstra(v1,v2);
	String s = "  pas de chemin";
	if (d > 0) s = df.format(Dijkstra(v1,v2) / 1000);

	System.out.println(v1.getNom()+" "+v2.getNom()+" "+s);
    }


    public static void test2(double minDist) {
	System.out.println();
    	System.out.println("France, pas de "+minDist);

    	initFrance(minDist);

    	Ville paris = premiereVille("Paris") ;
    	Ville rouen = premiereVille("Rouen");
	Ville palaiseau = premiereVille("Palaiseau");
	Ville perpignan = premiereVille("Perpignan");
	Ville strasbourg = premiereVille("Strasbourg");
	Ville hagenau = premiereVille("Hagenau");
	Ville brest = premiereVille("Brest");
	Ville hendaye = premiereVille("Hendaye");
		
    	afficheDijkstra(paris, rouen);
    	afficheDijkstra(palaiseau, rouen);
    	afficheDijkstra(palaiseau, paris);
	afficheDijkstra(paris, perpignan);
	afficheDijkstra(hendaye, perpignan);
	afficheDijkstra(paris, strasbourg);
	afficheDijkstra(hagenau, strasbourg);
	afficheDijkstra(hagenau, brest);


    }

    public static void main (String[] args) {

    	test1(1850);

    	test1(2000);

    	test1(3000);
    	test1(3400);
    	test1(4000);

	//tests sur la carte de France
	test2(2000);
	test2(5000);
	test2(7000);
	test2(10000);




    }



}
